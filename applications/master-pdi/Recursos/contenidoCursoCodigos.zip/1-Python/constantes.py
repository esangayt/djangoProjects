# -*- coding: utf-8 -*-
"""
Created on Wed Jul 14 21:10:41 2021

@author: Jesus-Mtz
"""

NOMBRE_PERSONA = "Jesús"
APELLIDO_PERSONA = "Mtz"

EDAD = 25
PI = 3.1416
