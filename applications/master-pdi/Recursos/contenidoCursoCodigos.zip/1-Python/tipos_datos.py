# -*- coding: utf-8 -*-
"""
Created on Wed Jul 14 20:22:27 2021

@author: Jesus-Mtz
"""

##Ejemplo hola mundo, desplegar mensaje en pantalla:
    
# print("Hola mundo")
# print("Estoy imprimiendo en pantalla")
# print("Mi nombre es Jesús Mtz")
# print("Curso de procesamiento digital de imagenes")


##Tipos de datos:

##Enteros o int:
##Son los numeros enteros desde -infinito a +infinito(limitados por la memoria de la computadora), -200, 500, -5, -400, 1, 2 8, 500000, -8000

##Con punto flotante o float:
##Son todos los numeros reales desde -infinito a +infinito(limitados por la memoria de la computadora), -1.1, -100.000005, 5.5, 9.84, 8.650698

##Booleanos o bool: Podemos definirlo como dos unicos valores, verdadero o falso: True, False

##Cadena de caracteres o string:
##Podemos definirlo como cualquier texto definido entre comillas dobles o comillas simples: "mensaje", "65896", "8 manzanas", 'perro', 'dsd8555',
## "esto es un 'mensaje' ", 'tambien podemos realizar "esto"'

##Listas o list: es una secuencia mutable, se puede modificar a lo largo del codigo
## [1,2,3,4,"j", "5", 8, 6]

##Tuplas o tuple: es una secuencia inmutable, no se puede modificar.
## (1,2,3,4,"j", "5", 8, 6)

##Es un tipo de dato que asocia claves con valores: {1: "algo", 2: 5, 3:'mensaje', "cuatro":12345}


##Variables y constantes:
##Los nombres de las variables pueden contener letras, numeros y guion bajo.
##El nombre puede comenzar con una letra o guion bajo, pero nunca con un numero
##El software distingue entre mayusculas y minusculas, ejemplo: no es lo mismo Escuela que escuela.
##Notación recomendada camelCase, ejemplo: nombreEscuela, nombrePersona, llantasCarro

##Ejemplos:

# valor1 = 5
# valor2 = 8

# print(valor1)
# print(valor2)
# print(valor1, valor2)
# print(valor2, valor1)

# print("la suma de estos valores es:", valor1 + valor2)
# print("la resta de estos valores es:", valor2 - valor1)

# suma = valor1 + valor2
# resta = valor2 - valor1

# print("la suma de estos valores es:", suma)
# print("la resta de estos valores es:", resta)

# nombrePersona = "jesus"
# apellidoPersona = "mtz"

# print("mi nombre es:", nombrePersona)
# print("mi apellido es:", apellidoPersona)

# print("mi nombre es: "+nombrePersona+" y mi apellido es: "+apellidoPersona)
# print("mi nombre completo es", nombrePersona+" "+apellidoPersona)

# print('mi nombre es {0} y mi apellido es {1}'.format(nombrePersona, apellidoPersona))
# print('mi nombre es {nombre} y mi apellido es {apellido}'.format(nombre = nombrePersona, apellido = apellidoPersona))

## Función input

# nombreCompleto = input("ingresa tu nombre completo: ")

# print("mi nombre completo es: ",nombreCompleto)


# valor1 = int(input("ingresa el valor 1: "))
# valor2 = int(input("ingresa el valor 2:"))

# suma = valor1 + valor2
# resta = valor2 - valor1

# print("el resultado de la suma es: ", suma)
# print("el resultado de la resta es: ", resta)

# suma = int(valor1) + int(valor2)
# resta = int(valor2) - int(valor1)

# print("el resultado de la suma es: ", suma)
# print("el resultado de la resta es: ", resta)


##Constantes ejemplos:

##Importar modulos

# import constantes

# print("el valor de pi es", constantes.PI)

# print("Mi nombre completo es {0} {1} y tengo {2} años de edad".format(constantes.NOMBRE_PERSONA, constantes.APELLIDO_PERSONA, constantes.EDAD))

# from constantes import NOMBRE_PERSONA, APELLIDO_PERSONA, EDAD

# print("Mi nombre completo es {0} {1} y tengo {2} años de edad".format(NOMBRE_PERSONA, APELLIDO_PERSONA, EDAD))








